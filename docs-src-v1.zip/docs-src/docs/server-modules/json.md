# encode

```lua
local json_str = core.json.encode( tbl )
```

# decode

```lua
local tbl = core.json.decode( json_str )
```
