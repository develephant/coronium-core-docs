To change the Coronium Core Webmin password, you must first log into the server using the __coronium__ user.

### webmin-passwd

Use this command line tool to change the Coronium Core Webmin password.

!!! info "Webmin Defaults"
    The Coronium Core Webmin user is always __cloudwebmin__. The default password is __cloudadmin__.

Run the following on the command line and follow the prompts:

```
sudo webmin-passwd
```
