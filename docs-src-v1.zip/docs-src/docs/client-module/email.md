
Send email messages using the __[Mailgun](https://mailgun.com)__ messaging service.

At this time email can only be sent using the server-side __[Email](/server-modules/email/)__ module.

To initiate an email from the client-side you must add a server-side API method using the __[API](/server-modules/api/)__ module.